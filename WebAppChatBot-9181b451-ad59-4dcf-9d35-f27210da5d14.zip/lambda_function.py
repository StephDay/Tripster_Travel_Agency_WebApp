import json
import boto3

lex_client = boto3.client('lex-runtime')

def lambda_handler(event, context):
    # Parse the incoming request
    request_body = json.loads(event['body'])
    message = request_body.get('message')

    # Invoke the Lex bot
    response = lex_client.post_text(
        botName='Tripster',
        botAlias='TestBotAlias',
        userId='3908-0024-0841',
        inputText=message
    )

    # Parse the response from Lex
    output_message = response['message']
    json_response = {
        'statusCode': 200,
        'body': json.dumps({
            'message': output_message
        }),
        'headers': {
            'Content-Type': 'application/json',
        },
    }

    return json_response
